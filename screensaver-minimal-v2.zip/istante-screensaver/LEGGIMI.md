# Istante · Screensaver 2.0

Un orologio, un pensiero, il tuo prossimo traguardo.

## Avvio rapido

Per provarlo su un computer, estrai tutto lo ZIP e apri `sito/index.html` nel browser. Non aprire il file direttamente dentro l'archivio compresso: prima estrailo.

Per pubblicarlo, carica **il contenuto della cartella `sito`** nella cartella web desiderata. Funziona anche in una sottocartella. Non servono compilazione, Node.js sul server, PHP, database o chiavi API. La cartella `sviluppo` e questo documento non vanno pubblicati.

Per una prova con un server locale, da un terminale aperto nella cartella `sito`:

```sh
python -m http.server 8000
```

Apri poi `http://localhost:8000` nel browser. Questo comando richiede Python; non serve invece per l'apertura diretta di `index.html` o per la pubblicazione su hosting statico.

## Come cambiano le frasi

La modalità iniziale è **Mattina & sera**:

- Dalle **06:00 alle 18:00**, un pensiero per il mattino.
- Dalle **18:00 alle 06:00 del giorno seguente**, un pensiero per la sera.

La selezione segue una sequenza mescolata. Una frase resta stabile per tutta la fascia, anche ricaricando la pagina. Il cambio avviene anche senza ricaricare e la frase serale non cambia a mezzanotte. Gli orari sono modificabili e seguono l'ora locale del dispositivo, non un fuso orario imposto dal server.

Le impostazioni permettono anche **Una al giorno**, **A intervalli** di 5, 15, 30 o 60 minuti, oppure **A ogni apertura**. La modalità giornaliera usa come cambio l'orario impostato per il mattino; quella a intervalli segue scadenze regolari dell'orologio. A ogni apertura significa un nuovo pensiero all'apertura o alla ricarica, senza cambi automatici nella stessa pagina.

Il pulsante con le frecce mostra subito un altro pensiero. Anche la raccolta permette di sceglierne uno manualmente: resta fino al prossimo cambio previsto, senza disattivare la rotazione. In modalità A ogni apertura resta fino alla prossima apertura.

## La raccolta

Sono incluse tutte le **700 frasi originali**, senza riscritture. Le introduzioni brevi, come “Ricorda:”, sono separate visivamente dal testo nella schermata principale, ma non vengono eliminate dalla raccolta o dalla copia del testo.

La raccolta offre ricerca per parola, preferiti, scelta manuale, importazione ed esportazione JSON. Il pulsante “Mostra altre frasi” carica altre righe, senza appesantire l'apertura del pannello.

L'algoritmo riconosce le varianti con introduzioni o finali ricorrenti presenti nell'elenco originale e le distanzia nella sequenza. Non assegna alle frasi categorie editoriali “mattina” o “sera”: entrambe le fasce usano la stessa raccolta.

Per importare una raccolta, puoi usare un array di testi oppure questo formato:

```json
{
  "version": "1.0",
  "language": "it",
  "count": 2,
  "phrases": [
    "Il tuo primo pensiero.",
    "Il tuo secondo pensiero."
  ]
}
```

Le raccolte importate sostituiscono l'elenco solo in quel browser. Il pulsante “Raccolta originale” ripristina i testi inclusi nel sito. Limiti dell'importazione: 2 MB, da 1 a 10.000 testi, massimo 1.000 caratteri per frase; eventuali duplicati identici vengono unificati. Nessun testo viene interpretato come codice HTML.

## Aspetto e traguardi

Le impostazioni includono i temi **Notte**, **Carta** e **Auto**, lo sfondo sfumato, la tinta unita o una fotografia locale. Con una foto il testo resta chiaro e puoi regolare l'oscuramento dello sfondo.

Puoi mostrare o nascondere orologio e secondi. Il conto alla rovescia predefinito punta al prossimo anno e si aggiorna automaticamente; puoi sostituirlo con un titolo e due date personali, oppure nasconderlo. Il progresso misura il tempo tra inizio e fine: prima dell'inizio resta a zero, dopo la scadenza resta al 100%, senza interrompere l'orologio.

I comandi si nascondono dopo 10 secondi di inattività e riappaiono con mouse, tocco o tastiera. I movimenti delicati possono essere disattivati e rispettano la preferenza del sistema per le animazioni ridotte.

Scorciatoie: **F** schermo intero, **N** altro pensiero, **L** raccolta, **S** impostazioni. **Esc** chiude i pannelli. Le scorciatoie non interferiscono con la scrittura nei campi.

## Dati locali e uso offline

Preferenze, preferiti, eventuale fotografia e raccolta importata vengono salvati nel browser. Non vengono inviati a un servizio esterno e non si sincronizzano automaticamente tra dispositivi. Cancellare i dati del sito può rimuoverli; usa l'esportazione JSON per conservare una copia della raccolta. L'esportazione riguarda le frasi, non tutte le preferenze o i preferiti.

Il sito usa solo file locali al progetto. Su HTTPS o localhost è incluso un service worker per conservare le risorse dopo il primo caricamento completato e consentirne il successivo uso offline, nei browser compatibili. La navigazione privata, le impostazioni di memoria e la rimozione della cache possono limitarlo. L'apertura diretta `file://` usa la copia JavaScript delle frasi e non il service worker; la persistenza locale in questa modalità dipende dal browser.

È uno screensaver **web**, non un programma che si registra come salvaschermo di Windows o macOS. Lo schermo intero richiede l'azione dell'utente. “Mantieni lo schermo acceso” è facoltativo e dipende dal browser, dal contesto sicuro e dalle politiche energetiche del dispositivo. Non è una garanzia contro sospensione, blocco del sistema o burn-in del display.

## File e manutenzione

`data/frasi_motivazionali_700.json` è la raccolta originale modificabile. Su un server web viene letta direttamente; `data/phrases.js` è la copia per l'apertura diretta e il ripiego in caso di errore nel caricamento JSON.

Dopo una modifica manuale al JSON, dalla cartella principale esegui:

```sh
python sviluppo/aggiorna-frasi.py
```

Pubblica entrambe le copie aggiornate. Incrementa anche la versione in `sito/sw.js` quando distribuisci nuove risorse, per rinnovare la cache offline.

I test e i dettagli di verifica sono in `sviluppo`. La licenza MIT del codice originario è conservata in `sito/LICENSE`; il file delle frasi è quello fornito per questo progetto.
