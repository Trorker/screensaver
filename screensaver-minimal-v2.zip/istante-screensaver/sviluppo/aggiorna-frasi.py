#!/usr/bin/env python3
"""Regenerate the file:// fallback after editing the canonical JSON collection."""
import json
from pathlib import Path
root = Path(__file__).resolve().parents[1] / 'sito'
source = root / 'data' / 'frasi_motivazionali_700.json'
data = json.loads(source.read_text(encoding='utf-8'))
phrases = data.get('phrases') if isinstance(data, dict) else data
if not isinstance(phrases, list) or not 1 <= len(phrases) <= 10000:
    raise SystemExit('Il JSON deve contenere un array phrases con 1-10000 testi.')
if any(not isinstance(p, str) or not p.strip() or len(p) > 1000 for p in phrases):
    raise SystemExit('Ogni frase deve essere un testo non vuoto di massimo 1000 caratteri.')
content = '// Generated from frasi_motivazionali_700.json. Do not edit this copy.\nwindow.ISTANTE_PHRASES = ' + json.dumps(data, ensure_ascii=True, separators=(',', ':')) + ';\n'
(root / 'data' / 'phrases.js').write_text(content, encoding='utf-8')
print(f'Raccolta aggiornata: {len(phrases)} frasi. Nessun testo modificato.')
