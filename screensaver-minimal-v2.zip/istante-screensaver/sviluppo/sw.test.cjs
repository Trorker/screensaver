const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const code = fs.readFileSync(require('node:path').join(__dirname, '../sito/sw.js'), 'utf8');
function harness() {
  const scope = 'https://example.test/screensaver/';
  const prefix = 'istante-' + encodeURIComponent(scope) + '-';
  const events = {}, calls = { deleted: [], stored: [], added: [] };
  let network = () => Promise.resolve(new Response('online'));
  let cached;
  const cache = {
    addAll: async files => { calls.added = Array.from(files); },
    put: async (request, response) => { calls.stored.push([request.url, await response.text()]); }
  };
  vm.runInNewContext(code, {
    self: { registration: { scope }, addEventListener: (name, fn) => events[name] = fn,
      skipWaiting: async () => {}, clients: { claim: async () => {} } },
    caches: { open: async () => cache,
      keys: async () => [prefix + '1.0.0', prefix + '2.0.0', 'another-application', 'istante-other-scope-1'],
      delete: async key => { calls.deleted.push(key); }, match: async () => cached },
    fetch: request => network(request), URL, Response, Set
  });
  return { scope, prefix, calls,
    network: fn => network = fn, cached: value => cached = value,
    lifecycle: name => new Promise((resolve, reject) => events[name]({ waitUntil: value => Promise.resolve(value).then(resolve, reject) })),
    request: (url, method = 'GET') => { let promise; events.fetch({ request: new Request(url, { method }), respondWith: value => promise = value }); return promise; }
  };
}
test('Offline shell includes HTML, scripts, JSON, styles and icons', async () => {
  const h = harness(); await h.lifecycle('install');
  assert.equal(h.calls.added.length, 11);
  for (const file of ['index.html', 'core.js', 'main.js', 'style.css', 'data/frasi_motivazionali_700.json']) assert.ok(h.calls.added.includes('./' + file));
});
test('Activation deletes only older caches for this installation scope', async () => {
  const h = harness(); await h.lifecycle('activate'); assert.deepEqual(h.calls.deleted, [h.prefix + '1.0.0']);
});
test('Successful network responses update local cache', async () => {
  const h = harness(); const response = await h.request(h.scope + 'main.js'); assert.equal(await response.text(), 'online'); assert.equal(h.calls.stored.length, 1);
});
test('Offline response falls back to the cached file', async () => {
  const h = harness(); h.network(async () => { throw new Error('offline'); }); h.cached(new Response('cached'));
  assert.equal(await (await h.request(h.scope + 'index.html')).text(), 'cached');
});
test('A network error without cached content produces a 503 response', async () => {
  const h = harness(); h.network(async () => { throw new Error('offline'); }); assert.equal((await h.request(h.scope + 'style.css')).status, 503);
});
test('Requests outside the known app assets or non-GET methods are ignored', () => {
  const h = harness(); assert.equal(h.request('https://external.test/image.png'), undefined);
  assert.equal(h.request(h.scope + 'private.json'), undefined); assert.equal(h.request(h.scope + 'index.html', 'POST'), undefined);
});
