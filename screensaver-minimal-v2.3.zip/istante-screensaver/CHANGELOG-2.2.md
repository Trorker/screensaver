# Istante 2.2

- Macchina da scrivere reale, carattere per carattere, ciclica e configurabile.
- Corretto il wrapping: le parole non vengono piu spezzate a meta.
- Audio Web Audio riscritto, sblocco su gesto utente e pulsante Prova suono.
- Preloader dedicato per evitare il flash dei dati iniziali.
- Widget opzionale alba/tramonto con arco solare animato.
- Tema Sole: chiaro tra alba e tramonto, scuro di notte.
- Modalita Momento con atmosfera alba/mattino/giorno/golden hour/tramonto/notte.
- Respiro ambientale opzionale.
- Restano sfondi automatici Picsum e atmosfera solare Open-Meteo.
