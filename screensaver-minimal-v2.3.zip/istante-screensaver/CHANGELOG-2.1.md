# Istante 2.1

## Novità

- Foto automatiche da Lorem Picsum, senza chiavi API.
- Intervallo sfondo: 5, 15, 30, 60, 120, 360, 720 o 1440 minuti.
- Seed temporale stabile: il refresh non cambia fotografia.
- Crossfade lento e movimento fotografico leggero.
- Oscuramento regolabile anche per le foto automatiche.
- Atmosfera solare opzionale con alba/tramonto reali da Open-Meteo.
- Posizione da browser oppure coordinate manuali; coordinate salvate solo localmente.
- Luce solare animata, golden hour, tramonto, luna e stelle minimali.
- Scrittura della frase parola per parola.
- Suono opzionale generato localmente con Web Audio, senza file musicali.
- Rispetto di `prefers-reduced-motion` e fallback quando rete/geolocalizzazione non sono disponibili.
- Cache offline aggiornata alla versione 2.1.0.

## Scelte tecniche

`unsplash-source-js` non è stato integrato perché il repository è archiviato e l'API Unsplash moderna richiede gestione protetta delle credenziali e specifiche regole di attribuzione. Picsum è più adatto a questo screensaver statico.
