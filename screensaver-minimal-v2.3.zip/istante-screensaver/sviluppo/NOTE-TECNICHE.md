# Note tecniche · Istante 2.1

## Struttura

Il sito è statico, in HTML, CSS e JavaScript, senza dipendenze da CDN. I caratteri sono quelli del sistema: nessun file di font viene distribuito. Le icone sono SVG locali.

`core.js` contiene funzioni pure per validazione, impostazioni, selezione, orari e conto alla rovescia. `main.js` gestisce interfaccia, timer, pannelli, memoria locale, sfondi Picsum, atmosfera solare Open-Meteo e Web Audio facoltativo. `sw.js` conserva soltanto le risorse pubbliche dichiarate, con un nome di cache distinto per percorso di installazione.

## Selezione delle frasi

I 700 testi originali formano 70 gruppi di varianti riconosciute. La sequenza è mescolata in modo deterministico usando come seme il contenuto della raccolta, poi alterna i gruppi. Nella raccolta inclusa le varianti di un gruppo sono separate di 70 posizioni. Questo descrive la sequenza automatica non modificata: selezioni manuali e cambi di modalità possono naturalmente riavvicinare frasi già viste.

La sequenza si ripete al termine dell'elenco; non vengono cancellate le frasi già mostrate. La modalità A ogni apertura esegue invece una nuova selezione, cercando di evitare il gruppo dell'ultima frase salvata. La scelta manuale è legata alla fascia corrente; non blocca quelle successive.

I cambi mattina/sera sono costruiti con date locali, non sommando sempre 24 ore. Sono presenti test specifici per il cambio tra ora solare e legale. Date, orari e avanzamento dipendono dall'orologio del dispositivo: non c'è una sincronizzazione NTP o un server orario dell'applicazione.

## Memoria locale

Le chiavi `localStorage` iniziano con `istante.v2.`. Due installazioni nello stesso origin condividono queste preferenze: il percorso URL non isola localStorage. La cache offline, invece, è distinta per scope. I preferiti sono memorizzati usando il testo completo. Errori di accesso o memoria piena non impediscono l'uso della sessione e vengono segnalati quando una modifica non può essere salvata.

La foto viene ridimensionata fino a 1920 pixel sul lato lungo e convertita in JPEG locale; il caricamento non modifica il file originale. Dimensione massima del file: 15 MB. Viene applicato anche un limite alle dimensioni decodificate.

## Funzioni online

Gli sfondi automatici usano URL `picsum.photos/seed/...` derivati dalla fascia temporale: il seed evita cambi al semplice refresh. Le immagini remote non vengono aggiunte alla cache offline del service worker. L'atmosfera solare richiede `sunrise` e `sunset` a Open-Meteo solo con coordinate esplicitamente impostate; in errore usa un fallback locale e non interrompe l'interfaccia. Il suono è sintetizzato con Web Audio e non contiene file audio o chiamate esterne.

## Verifiche effettuate

Sono passati **27 test automatici Node.js**: 21 sulla logica applicativa e 6 sul service worker con richieste e cache simulate. Coprono preservazione dei testi, sequenza e gruppi, cambi orari, mezzanotte, fuso Europe/Rome e ora legale, anni bisestili, intervalli, sanificazione impostazioni, scadenze e isolamento delle cache.

La versione 2.0 aveva superato **34 controlli dell'interfaccia in Chromium** senza errori JavaScript rilevati: ricerca, paginazione, preferiti, ripristino dello stato, selezione manuale, cambio automatico, form, importazione invalida, contenuti HTML trattati come testo, tema automatico, inattività e riattivazione.

La verifica visiva della versione 2.0 ha incluso nove risoluzioni da 320×568 a 2560×1080, anche orizzontali, con le 30 frasi originali più lunghe: non sono risultati overflow orizzontali o verticali nella schermata principale con le impostazioni predefinite.

L'interfaccia è stata caricata con il codice reale in una pagina isolata, usando un adattatore di memoria per i test. Le restrizioni del browser di verifica impedivano la normale navigazione: **non è stato eseguito un collaudo end-to-end della pubblicazione HTTPS, della registrazione nativa del service worker, della persistenza nativa su disco, di schermo intero e Screen Wake Lock**. Safari/iOS e Firefox non sono stati collaudati direttamente. La presenza di controlli sulle API facoltative non sostituisce la verifica sul dispositivo finale.

`VERIFICHE-UI.json` contiene l'elenco dei controlli e delle dimensioni; `VERIFICHE-UNIT.txt` contiene il rapporto dei test unitari.

Per ripetere i test della logica e del service worker, serve Node.js con il test runner integrato e le API Request/Response:

```sh
node --test sviluppo/core.test.cjs sviluppo/sw.test.cjs
```

Lo script `aggiorna-frasi.py` richiede soltanto la libreria standard di Python. L'uso del sito non richiede questi strumenti.


Per la versione 2.1 sono stati rieseguiti con esito positivo i 27 test Node.js e i controlli sintattici di `core.js` e `main.js`. Le funzioni che dipendono da rete, geolocalizzazione e autorizzazioni audio vanno collaudate anche nel browser/dispositivo di pubblicazione, perché tali permessi non sono simulati dai test Node.js.
