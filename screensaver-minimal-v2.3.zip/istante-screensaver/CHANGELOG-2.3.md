# Istante 2.3

- Audio macchina da scrivere molto piu presente, con volume esteso fino al 100% e nuovo gain/compressore Web Audio.
- Atmosfera solare resa resiliente: funziona anche senza coordinate usando orari locali di fallback, e usa Open-Meteo quando la posizione e disponibile.
- Percorso alba/tramonto ridisegnato come elemento integrato nella composizione, senza card o widget flottante.
- Tipografia desktop ingrandita in modo deciso: orologio, frase, countdown e microtesti principali.
- Select, ora, data, datetime e slider armonizzati allo stile di Istante.
- Cache service worker aggiornata alla versione 2.3.
