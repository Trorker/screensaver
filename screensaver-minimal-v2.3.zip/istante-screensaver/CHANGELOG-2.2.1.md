# Istante 2.2.1

## Miglioramenti tablet
- Aumentata la dimensione di frase, orologio, data, countdown e metadati sui tablet.
- Ingranditi widget solare, pulsanti touch e testi dei pannelli impostazioni/raccolta.
- Aggiunta gestione specifica per iPad Pro e tablet touch con larghezza simile a un desktop.
- Corretta la scala tipografica anche in orientamento orizzontale con altezza ridotta.
- Cache del service worker aggiornata alla 2.2.1.
