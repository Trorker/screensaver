# Istante · Screensaver 2.1

Un orologio, un pensiero, il tuo prossimo traguardo.

## Avvio rapido

Per provarlo su un computer, estrai tutto lo ZIP e apri `sito/index.html` nel browser. Non aprire il file direttamente dentro l'archivio compresso: prima estrailo.

Per pubblicarlo, carica **il contenuto della cartella `sito`** nella cartella web desiderata. Funziona anche in una sottocartella. Non servono compilazione, Node.js sul server, PHP, database o chiavi API. Le funzioni online per sfondi e atmosfera solare sono facoltative. La cartella `sviluppo` e questo documento non vanno pubblicati.

Per una prova con un server locale, da un terminale aperto nella cartella `sito`:

```sh
python -m http.server 8000
```

Apri poi `http://localhost:8000` nel browser. Questo comando richiede Python; non serve invece per l'apertura diretta di `index.html` o per la pubblicazione su hosting statico.

## Come cambiano le frasi

La modalità iniziale è **Mattina & sera**:

- Dalle **06:00 alle 18:00**, un pensiero per il mattino.
- Dalle **18:00 alle 06:00 del giorno seguente**, un pensiero per la sera.

La selezione segue una sequenza mescolata. Una frase resta stabile per tutta la fascia, anche ricaricando la pagina. Il cambio avviene anche senza ricaricare e la frase serale non cambia a mezzanotte. Gli orari sono modificabili e seguono l'ora locale del dispositivo, non un fuso orario imposto dal server.

Le impostazioni permettono anche **Una al giorno**, **A intervalli** di 5, 15, 30 o 60 minuti, oppure **A ogni apertura**. La modalità giornaliera usa come cambio l'orario impostato per il mattino; quella a intervalli segue scadenze regolari dell'orologio. A ogni apertura significa un nuovo pensiero all'apertura o alla ricarica, senza cambi automatici nella stessa pagina.

Il pulsante con le frecce mostra subito un altro pensiero. Anche la raccolta permette di sceglierne uno manualmente: resta fino al prossimo cambio previsto, senza disattivare la rotazione. In modalità A ogni apertura resta fino alla prossima apertura.

## La raccolta

Sono incluse tutte le **700 frasi originali**, senza riscritture. Le introduzioni brevi, come “Ricorda:”, sono separate visivamente dal testo nella schermata principale, ma non vengono eliminate dalla raccolta o dalla copia del testo.

La raccolta offre ricerca per parola, preferiti, scelta manuale, importazione ed esportazione JSON. Il pulsante “Mostra altre frasi” carica altre righe, senza appesantire l'apertura del pannello.

L'algoritmo riconosce le varianti con introduzioni o finali ricorrenti presenti nell'elenco originale e le distanzia nella sequenza. Non assegna alle frasi categorie editoriali “mattina” o “sera”: entrambe le fasce usano la stessa raccolta.

Per importare una raccolta, puoi usare un array di testi oppure questo formato:

```json
{
  "version": "1.0",
  "language": "it",
  "count": 2,
  "phrases": [
    "Il tuo primo pensiero.",
    "Il tuo secondo pensiero."
  ]
}
```

Le raccolte importate sostituiscono l'elenco solo in quel browser. Il pulsante “Raccolta originale” ripristina i testi inclusi nel sito. Limiti dell'importazione: 2 MB, da 1 a 10.000 testi, massimo 1.000 caratteri per frase; eventuali duplicati identici vengono unificati. Nessun testo viene interpretato come codice HTML.

## Aspetto e traguardi

Le impostazioni includono i temi **Notte**, **Carta** e **Auto**, lo sfondo sfumato, la tinta unita, una fotografia locale oppure **Foto automatiche**. In quest'ultima modalità Istante usa Lorem Picsum e mantiene la stessa immagine per l'intervallo scelto (5 minuti, 15 minuti, 30 minuti, 1/2/6/12 ore o 1 giorno), così un semplice refresh non cambia fotografia. Il passaggio alla successiva usa un crossfade lento e un leggerissimo movimento fotografico. Con una foto il testo resta chiaro e puoi regolare l'oscuramento dello sfondo.

**Atmosfera solare** è opzionale. Dopo aver indicato latitudine/longitudine o aver premuto “Usa la mia posizione”, il sito richiede a Open-Meteo gli orari reali di alba e tramonto e muove una luce molto discreta durante la giornata; intorno a alba e tramonto compare una tinta più calda, mentre di notte compaiono luna e stelle leggere. Se il servizio non risponde, viene usata temporaneamente una stima locale senza bloccare la pagina. I dati Open-Meteo sono mostrati con attribuzione come richiesto dalla licenza.

La **scrittura della frase** può far comparire il testo parola per parola. Il **suono della frase** è disattivato di default: se attivato usa Web Audio per generare localmente un piccolo accordo e micro-toni, senza scaricare file audio. Per le regole autoplay dei browser il suono parte soltanto dopo una prima interazione dell'utente.

Puoi mostrare o nascondere orologio e secondi. Il conto alla rovescia predefinito punta al prossimo anno e si aggiorna automaticamente; puoi sostituirlo con un titolo e due date personali, oppure nasconderlo. Il progresso misura il tempo tra inizio e fine: prima dell'inizio resta a zero, dopo la scadenza resta al 100%, senza interrompere l'orologio.

I comandi si nascondono dopo 10 secondi di inattività e riappaiono con mouse, tocco o tastiera. I movimenti delicati possono essere disattivati e rispettano la preferenza del sistema per le animazioni ridotte.

Scorciatoie: **F** schermo intero, **N** altro pensiero, **L** raccolta, **S** impostazioni. **Esc** chiude i pannelli. Le scorciatoie non interferiscono con la scrittura nei campi.

## Dati locali e uso offline

Preferenze, preferiti, eventuale fotografia, coordinate e raccolta importata vengono salvati nel browser e non si sincronizzano automaticamente tra dispositivi. La fotografia personale non viene inviata a servizi esterni. Quando scegli **Foto automatiche**, il browser carica direttamente l'immagine da `picsum.photos`; quando abiliti **Atmosfera solare**, invia latitudine e longitudine a Open-Meteo per ottenere alba e tramonto. Cancellare i dati del sito può rimuoverli; usa l'esportazione JSON per conservare una copia della raccolta. L'esportazione riguarda le frasi, non tutte le preferenze o i preferiti.

Il nucleo del sito usa file locali al progetto; le due funzioni online appena descritte sono facoltative. Su HTTPS o localhost è incluso un service worker per conservare le risorse dopo il primo caricamento completato e consentirne il successivo uso offline, nei browser compatibili. La navigazione privata, le impostazioni di memoria e la rimozione della cache possono limitarlo. L'apertura diretta `file://` usa la copia JavaScript delle frasi e non il service worker; la persistenza locale in questa modalità dipende dal browser.

È uno screensaver **web**, non un programma che si registra come salvaschermo di Windows o macOS. Lo schermo intero richiede l'azione dell'utente. “Mantieni lo schermo acceso” è facoltativo e dipende dal browser, dal contesto sicuro e dalle politiche energetiche del dispositivo. Non è una garanzia contro sospensione, blocco del sistema o burn-in del display.

## File e manutenzione

`data/frasi_motivazionali_700.json` è la raccolta originale modificabile. Su un server web viene letta direttamente; `data/phrases.js` è la copia per l'apertura diretta e il ripiego in caso di errore nel caricamento JSON.

Dopo una modifica manuale al JSON, dalla cartella principale esegui:

```sh
python sviluppo/aggiorna-frasi.py
```

Pubblica entrambe le copie aggiornate. Incrementa anche la versione in `sito/sw.js` quando distribuisci nuove risorse, per rinnovare la cache offline.

I test e i dettagli di verifica sono in `sviluppo`. La licenza MIT del codice originario è conservata in `sito/LICENSE`; il file delle frasi è quello fornito per questo progetto.

## Novita 2.2

- Preloader iniziale per evitare il flash dei dati prima dell'inizializzazione.
- Effetto macchina da scrivere carattere per carattere, ciclico e configurabile.
- Audio Web Audio riscritto con sblocco al primo gesto e pulsante **Prova suono**.
- Wrapping delle frasi corretto: le parole non vengono spezzate a meta.
- Widget opzionale alba/tramonto con arco e posizione del sole durante il giorno.
- Tema **Sole**: chiaro tra alba e tramonto, scuro di notte.
- Modalita **Momento**: alba, mattino, giorno, golden hour, tramonto e notte influenzano l'accento visivo.
- **Respiro ambientale** opzionale con variazione lentissima della luce.

### Nota audio

I browser moderni bloccano l'audio automatico prima di una interazione dell'utente. Istante sblocca il motore audio al primo click, tocco o tasto. Nelle impostazioni, attiva il suono e usa **Prova suono** per verificarlo immediatamente.

### Nota alba e tramonto

Per gli orari reali attiva **Atmosfera solare** e usa **Usa la mia posizione** oppure inserisci latitudine e longitudine. Su un sito pubblicato e consigliato HTTPS; alcuni browser limitano geolocalizzazione e Wake Lock su contesti non sicuri.
